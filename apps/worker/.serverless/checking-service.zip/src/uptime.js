"use strict";

// src/utils/customHeader.ts
var createHeaders = (headers) => {
  return { ...headers };
};

// src/utils/fetch.ts
async function fetcher({
  url,
  httpMethods,
  httpRequestBody,
  headerName,
  headerValue,
  httpRequestTimeout = "1200"
}) {
  const timeoutSignal = AbortSignal.timeout(Number(httpRequestTimeout));
  let customHeaders;
  if (headerName && headerValue) {
    customHeaders = createHeaders({
      [headerName]: headerValue,
      "Content-Type": "application/json"
    });
    console.log("Custom Header: ", {
      headers: { ...customHeaders }
    });
  }
  try {
    const response = await fetch(url, {
      method: httpMethods ?? "GET",
      body: httpRequestBody,
      headers: customHeaders ? { ...customHeaders } : {},
      signal: timeoutSignal
    });
    console.log("RESPONSEEEEE: ", response);
    return response;
  } catch (err) {
    const error = err;
    if (error.name === "TimeoutError") {
      console.error(`Timeout: It took more than ${httpRequestTimeout} seconds to get the result!`);
      throw err;
    } else if (error.name === "AbortError") {
      console.error(
        "Fetch aborted by user action (browser stop button, closing tab, etc."
      );
      throw err;
    } else if (error.name === "TypeError") {
      console.error(err);
    } else {
      console.error(`Error: type: ${error}, message: ${error.message}`);
    }
  }
}

// src/uptime.ts
module.exports.handler = async (event) => {
  const {
    url,
    regions,
    headerName,
    headerValue,
    httpMethods,
    httpRequestTimeout,
    httpRequestBody
  } = event;
  const start = performance.now();
  const response = await fetcher({
    url,
    regions,
    headerName,
    headerValue,
    httpMethods,
    httpRequestTimeout,
    httpRequestBody
  });
  const end = performance.now();
  const statusCode = response?.status;
  const headers = response?.headers;
  const isOk = response?.ok;
  return {
    statusCode: 200,
    // status code of the lambda function
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      message: "OKAY BHAI",
      responseTime: `${(end - start).toFixed(0)} ms`,
      responseData: {
        statusCode,
        headers,
        isOk
      }
    })
  };
};
